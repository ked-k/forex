<footer class="page-footer">
    <p class="mb-0">Copyright ©{{date('Y')}}. <a target="_blank" href="https://ripontechug.com/">Ripon Technologies Ug Ltd</a> all right reserved.  <a target="_blank" href="https://ked.ripontechug.com">@ked</a></p>
</footer>
